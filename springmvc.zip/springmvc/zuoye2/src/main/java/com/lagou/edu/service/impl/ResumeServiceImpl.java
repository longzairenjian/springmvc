package com.lagou.edu.service.impl;

import com.lagou.edu.dao.ResumeDao;
import com.lagou.edu.pojo.Resume;
import com.lagou.edu.service.ResumeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
/**
 * @Author joker
 * @Date 2020-09-30
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class ResumeServiceImpl implements ResumeService {

    @Autowired
    private ResumeDao resumeDao;

    @Override
    public List<Resume> queryAccountList()  {
        return resumeDao.findAll();
    }

    @Override
    public void update(Resume resume) {
        resumeDao.save(resume);
    }

    @Override
    public void save(Resume resume) {
        resumeDao.save(resume);
    }

    @Override
    public void delete(Resume resume) {
        resumeDao.delete(resume);
    }
}
