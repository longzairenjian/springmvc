package com.lagou.edu.controller;

import com.lagou.edu.dao.ResumeDao;
import com.lagou.edu.pojo.Resume;
import com.lagou.edu.service.ResumeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * @Author joker
 * @Date 2020-09-30
 */
@Controller
public class JspController {
    @Autowired
    private ResumeService resumeService;

    @RequestMapping("list")
    public String findAll(Model model, HttpServletRequest request) {
        List<Resume> resumes = resumeService.queryAccountList();
        model.addAttribute("resumes", resumes);
        return "list.jsp";
    }

    @RequestMapping("update")
    public String update(Resume resume) {
        resumeService.update(resume);
        return "redirect:list";
    }

    @RequestMapping("save")
    public String save(Resume resume) {
        resumeService.save(resume);
        return "redirect:list";
    }

    @RequestMapping("delete")
    public String delete(Integer id) {
        Resume resume = new Resume();
        resume.setId(id);
        resumeService.delete(resume);
        return "redirect:list";
    }
}
