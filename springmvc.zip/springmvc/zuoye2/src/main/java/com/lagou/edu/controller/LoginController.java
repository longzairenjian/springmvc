package com.lagou.edu.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
/**
 * @Author joker
 * @Date 2020-09-30
 */
@Controller
@RequestMapping("/user")
public class LoginController {

    @RequestMapping("/login")
    public String login(String username, String password, HttpServletRequest request){
        if("admin".equals(username)&&"admin".equals(password)){
            request.getSession().setAttribute("admin","admin");
            return "/list";
        }else {
            return "/login.jsp";
        }

    }

}
