package com.lagou.edu.service;

import com.lagou.edu.pojo.Resume;

import java.util.List;
/**
 * @Author joker
 * @Date 2020-09-30
 */
public interface ResumeService {
    List<Resume> queryAccountList();

    void update(Resume resume);

    void save(Resume resume);

    void delete(Resume resume);
}
