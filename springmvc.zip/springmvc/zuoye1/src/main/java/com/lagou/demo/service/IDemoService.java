package com.lagou.demo.service;
/**
 * @Author joker
 * @Date 2020-09-27
 */
public interface IDemoService {

    String get(String name);
}
