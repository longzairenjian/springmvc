package com.lagou.edu.mvcframework.annotations;

import java.lang.annotation.*;

/**
 * @Author joker
 * @Date 2020-09-27
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.TYPE})
public @interface Security {
    String[] value() default "";
}
